#ifndef _T_CONTENTDISPOSITION_H_
#define _T_CONTENTDISPOSITION_H_
#include <string>
#include "cutee.h"


namespace mimetic
{

struct TEST_CLASS( contentdisposition)
{
    void TEST_FUNCTION( parser0 );
    void TEST_FUNCTION( parser1 );
};

}

#endif

