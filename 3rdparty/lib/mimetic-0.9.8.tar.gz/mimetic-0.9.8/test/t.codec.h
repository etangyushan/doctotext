#ifndef _T_CODEC_H_
#define _T_CODEC_H_
#include <string>
#include "cutee.h"


namespace mimetic
{

struct TEST_CLASS( test_codec )
{
    void TEST_FUNCTION( one );
};

}

#endif

