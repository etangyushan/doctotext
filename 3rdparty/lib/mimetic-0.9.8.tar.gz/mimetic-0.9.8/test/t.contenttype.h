#ifndef _T_CONTENTTYPE_H_
#define _T_CONTENTTYPE_H_
#include <string>
#include "cutee.h"


namespace mimetic
{

struct TEST_CLASS( contenttype )
{
    void TEST_FUNCTION( parser );
};

}

#endif

